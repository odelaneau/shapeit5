#unmount
fusermount -u /home/olivier/Fuse

#mount
~/Tools/dxfuse-linux /home/olivier/Fuse PhasingUKB
