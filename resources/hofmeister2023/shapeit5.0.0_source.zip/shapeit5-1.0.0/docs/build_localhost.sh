#!/bin/bash

bundle exec jekyll serve
