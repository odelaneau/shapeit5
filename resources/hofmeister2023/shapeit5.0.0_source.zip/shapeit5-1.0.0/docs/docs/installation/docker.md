---
layout: default
title: Docker
nav_order: 3
parent: Installation
has_children: false
permalink: /docs/installation/docker
---

{: .warning }
Docker image not yet available. The docker image will be available with the first relase at the following link

# Docker image

SHAPEIT5 provides a Dockerfile and scripts to create a minimal docker image. To download a ready-made docker image please download it from here:

[https://github.com/odelaneau?tab=packages&repo_name=shapeit5](https://github.com/odelaneau?tab=packages&repo_name=shapeit5).
