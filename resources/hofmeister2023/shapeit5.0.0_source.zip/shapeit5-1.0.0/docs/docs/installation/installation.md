---
layout: default
title: Installation
nav_order: 2
has_children: true
permalink: /docs/installation
---

# Installation

Installation instructions of SHAPEIT5
{: .fs-6 .fw-300 }
