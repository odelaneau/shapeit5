---
layout: default
title: Build from source
nav_order: 1
parent: Installation
has_children: true
permalink: /docs/installation/build_from_source
---

# Build from source

Installation instructions of SHAPEIT5
{: .fs-6 .fw-300 }
