---
layout: default
title: Documentation
nav_order: 3
has_children: true
permalink: /docs/documentation
---
# Documentation

Command-line documentation and usage of SHAPEIT5
{: .fs-6 .fw-300 }

Click on a tool below to see its documentation.
