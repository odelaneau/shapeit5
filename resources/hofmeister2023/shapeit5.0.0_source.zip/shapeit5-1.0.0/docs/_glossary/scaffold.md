---
title: Haplotype scaffold
---

A haplotype scaffold is a set of highly confident haplotypes, typically on a subset of the data. SHAPEIT5 uses the haplotypes derived at common variants as haplotype scaffolds onto which heterozygous genotypes are phased one rare variant at a time.
