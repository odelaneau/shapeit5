---
title: Whole exome sequencing (WES)
---

Whole exome sequencing (WES) is a technique for sequencing all of the protein-coding regions of genes in a genome. In the UK Biobank dataset, we combined WES with SNP array data and performed phasing with SHAPEIT5.
