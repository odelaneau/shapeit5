---
title: UK Biobank Research Analysis Platform
---

The UK Biobank Research Analysis Platform (RAP), enabled by DNAnexus and Amazon Web Services (AWS), is a cloud-based platform that enables researchers to work with the UK Biobank WGS and WES data.

Resources:
- [UK Biobank website](https://www.ukbiobank.ac.uk/enable-your-research/research-analysis-platform){:target='_blank' rel='noopener'} 
