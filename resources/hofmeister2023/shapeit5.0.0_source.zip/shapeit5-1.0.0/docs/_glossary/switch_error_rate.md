---
title: Switch error rate
---

Switch error rate (SER) is a popular metric to measure the quality of phased data. SER is used when known maternal and paternal haplotypes are available and is defined as the number of switch errors divided by the number of opportunities for switch errors.
