---
title: Reference panel
---

A reference panel is a large set of deeply-sequenced haplotypes used for genotype imputation and haplotype phasing typically for cohorts genotyped using SNP array or low-coverage WGS.
