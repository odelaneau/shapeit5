---
title: CHANGELOG
layout: default
---

# CHANGELOG

All notable changes to this project are documented in this file.

{: .highlight }
Version 1.0.0 will be released on the 15th of November 2022.

## v1.0.0

- First release. Version used for the preprint
